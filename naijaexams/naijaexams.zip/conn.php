<?php
$servername = "localhost";
$username = "naijaexa";
$password = "hs9xx0IQ25";
$database="naijaexa_new";

// Create connection
$conn = new mysqli($servername, $username, $password, $database);

if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
} 
?>